/* **********************************************************
 * Copyright 2000 VMware, Inc.  All rights reserved. -- VMware Confidential
 * **********************************************************/

/*
 * scattergather.h --
 *
 *	Scatter gather structure.
 */


#ifndef _SCATTER_GATHER_H
#define _SCATTER_GATHER_H

#define INCLUDE_ALLOW_USERLEVEL
#define INCLUDE_ALLOW_VMMEXT
#define INCLUDE_ALLOW_MODULE
#define INCLUDE_ALLOW_VMK_MODULE
#define INCLUDE_ALLOW_VMKERNEL
#define INCLUDE_ALLOW_DISTRIBUTE
#include "includeCheck.h"

#define SG_DEFAULT_LENGTH	8

typedef struct SG_Elem {
   uint64	offset;
   uint64 	addr;
   uint32	length;
} SG_Elem;

typedef enum SG_AddrType {
   SG_MACH_ADDR,
   SG_PHYS_ADDR,
   SG_VIRT_ADDR,
} SG_AddrType;

typedef struct SG_Array {
   SG_AddrType	addrType;
   uint32	length;
   SG_Elem	sg[SG_DEFAULT_LENGTH];
} SG_Array;

#define SG_ARRAY_SIZE(len) (sizeof(SG_Array) + ((len) - SG_DEFAULT_LENGTH) * sizeof(SG_Elem))

static INLINE uint32
SG_TotalLength(SG_Array *sgArr)
{
   uint32 totLen = 0;
   uint32 i;

   for (i = 0; i < sgArr->length; i++) {
      totLen += sgArr->sg[i].length;
   }

   return totLen;
}

#endif
